import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
// import { DetailsComponent } from './details/details.component';
import { PostsComponent } from './posts/posts.component';
import { HelloFrameworkComponent } from './hello-framework/hello-framework.component'


 const routes: Routes = [
  {
      path: 'posts',
      component: PostsComponent
  },
  {
    path: '',
    component: HelloFrameworkComponent
  }
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

//   {
//     path: '',
//     component: UsersComponent
//   },
//  {
//      path: 'details/:id',
//     component: DetailsComponent
//   },
//   {
//     path: 'posts',
//     component: PostsComponent
//   },
// ];