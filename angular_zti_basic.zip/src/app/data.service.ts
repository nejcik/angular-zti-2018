import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Http, Response } from '@angular/http';
import {Observable } from 'rxjs/Observable';


@Injectable({
  providedIn: 'root'
})
export class DataService {

  
  constructor(private http: HttpClient) { }

  getPosts() {
    return this.http.get  ('https://jsonplaceholder.typicode.com/posts')
  }

}


